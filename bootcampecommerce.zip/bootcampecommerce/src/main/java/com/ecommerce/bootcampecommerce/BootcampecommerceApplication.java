package com.ecommerce.bootcampecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootcampecommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootcampecommerceApplication.class, args);
	}

}
