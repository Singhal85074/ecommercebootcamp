package com.ecommerce.bootcampecommerce.controller;

import com.ecommerce.bootcampecommerce.entity.Customer;
import com.ecommerce.bootcampecommerce.entity.User;
import com.ecommerce.bootcampecommerce.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/user")
public class CustomerController {

    @Autowired
    CustomerRepository repo;

    @GetMapping("/customer")
    public List<Customer> getAllCustomer(){
        return repo.findAll();
    }

    @PostMapping("/customer")
    public ResponseEntity<Object> registerSeller(@Valid @RequestBody Customer customer){
        User user = customer.getUser();
        String password = user.getPassword();
        String confirmPassword = user.getConfirmPassword();
        if (password.equals(confirmPassword)) {
            return new ResponseEntity<>(repo.save(customer), HttpStatus.CREATED);
        }else {
            return new ResponseEntity<>("Password doesn't matched. \nPlease Check the confirm password and try again",HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
