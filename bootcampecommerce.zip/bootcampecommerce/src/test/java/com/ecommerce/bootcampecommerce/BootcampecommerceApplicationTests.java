package com.ecommerce.bootcampecommerce;

import com.ecommerce.bootcampecommerce.entity.Address;
import com.ecommerce.bootcampecommerce.entity.Customer;
import com.ecommerce.bootcampecommerce.entity.Seller;
import com.ecommerce.bootcampecommerce.entity.User;
import com.ecommerce.bootcampecommerce.repository.CustomerRepository;
import com.ecommerce.bootcampecommerce.repository.SellerRepository;
import com.ecommerce.bootcampecommerce.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import java.util.HashSet;
import java.util.Set;

@SpringBootTest
class BootcampecommerceApplicationTests {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	SellerRepository sellerRepository;

	@Test
	void contextLoads() {
	}

	@Test
	void createCustomer(){
		User user = new User();
		user.setFirstName("Yash");
		user.setLastName("Singh");
		user.setEmail("test123ddfdsfs@gmail.com");
		user.setPassword("Yash@1234");

		Address address1 = new Address();
		address1.setCity("muzaffarpur");
		address1.setState("bihar");
		address1.setCountry("india");
		address1.setZipcode("842001");
		address1.setAddressline("bhahwanpur chatti rewa road");
		address1.setLabel("home");

		Address address2 = new Address();
		address2.setCity("delhi");
		address2.setState("bihar");
		address2.setCountry("india");
		address2.setZipcode("842001");
		address2.setAddressline("bhahwanpur chatti rewa road");
		address2.setLabel("home");

		Set<Address> addressSet = new HashSet<>();
		addressSet.add(address1);
		addressSet.add(address2);

		Customer customer = new Customer();
		customer.setContactNumber("8090151253");
		user.setAddresses(addressSet);
		customer.setUser(user);

		customerRepository.save(customer);
	}

	@Test
	void createSeller(){
		User user = new User();
		user.setFirstName("Somesh");
		user.setLastName("kumar");
		user.setEmail("somesh456@gmail.com");
		user.setPassword("Somesh@1234");

		Address address1 = new Address();
		address1.setCity("Gonda");
		address1.setState("U.P");
		address1.setCountry("india");
		address1.setZipcode("271002");
		address1.setAddressline("Badgaon");
		address1.setLabel("home");

		Set<Address> addressSet = new HashSet<>();
		addressSet.add(address1);

		Seller seller = new Seller();
		seller.setGST("83JKWSQ1WI");
		seller.setCompanyContact("7373737373");
		seller.setCompanyName("TTN");
		user.setAddresses(addressSet);
		seller.setUser(user);

		sellerRepository.save(seller);

	}
}
